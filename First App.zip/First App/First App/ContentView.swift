//
//  ContentView.swift
//  First App
//
//  Created by Angi Shi on 2024-09-22.
//

import SwiftUI

struct ContentView: View {
    @State private var name: String = ""
    @State private var number: String = ""
    @State private var nameEntered: Bool = false
    @State private var numberEntered: Bool = false
    @State private var sliderValue: Double = 50
    @State private var switchesSelected: Bool = true
    @State private var toggleOn: Bool = false
    @State private var showPopup: Bool = false
    
    
    @State private var showBlankLayer: Bool = false

        var body: some View {
            ZStack {
                VStack {
                    VStack {
                        Image("LINDSAY Logo-Upper")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .padding(.bottom, 50)
                    }

                    HStack {
                        Text("Name:")
                            .font(.system(size: 20))
                        TextField("Type in a name", text: $name, onEditingChanged: { isEditing in
                            if name.isEmpty {
                                nameEntered = true
                            }
                        })
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.default)
                            .submitLabel(.done)
                    }
                    .padding(.horizontal)
                    
                    HStack {
                        Text("Number:")
                            .font(.system(size: 20))
                        TextField("Type in a number", text: $number, onEditingChanged: { isEditing in
                            if number.isEmpty {
                                numberEntered = true
                            }
                        })
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)

                        Button("Set Number") {
                            print("Number set to: \(number)")
                            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                        }
                        .frame(width: 95)
                        .padding(.vertical, 10)
                        .padding(.horizontal, 10)
                        .foregroundColor(.black)
                        .background(Color(red: 1.0, green: 0.35, blue: 0.0))
                    }
                    .padding()
                    
                    Text(name.isEmpty ? (nameEntered ? "Name field has been cleared.": "No name typed in yet.") : "Hello, \(name)")
                        .font(.system(size: 20))
                        .foregroundColor(.gray)
                        .padding(.bottom, 10)

                    Text(number.isEmpty ? (numberEntered ? "Number field has been cleared.": "No number typed in yet.") : "The entered number is: \(number)")
                        .font(.system(size: 20))
                        .foregroundColor(.gray)
                        .padding(.bottom, 10)
                    
                    VStack {
                        Text("\(Int(sliderValue))")
                            .font(.system(size: 22))
                            .bold()
                            .padding(.bottom, 10)

                        Slider(value: $sliderValue, in: 0...100, step: 1)
                            .padding(.horizontal, 120)
                    }
                    .padding()

                    HStack(spacing: 0) {
                        Button(action: {
                            switchesSelected = true
                        }) {
                            Text("Switches")
                                .font(.system(size: 20))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 10)
                                .frame(maxWidth: 105)
                                .background(switchesSelected ? Color.blue : Color.white)
                                .foregroundColor(switchesSelected ? Color.white : Color.blue)
                                .cornerRadius(10)
                        }

                        Button(action: {
                            switchesSelected = false
                        }) {
                            Text("Button")
                                .font(.system(size: 20))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 10)
                                .frame(maxWidth: 105)
                                .background(!switchesSelected ? Color.blue : Color.white)
                                .foregroundColor(!switchesSelected ? Color.white : Color.blue)
                                .cornerRadius(10)
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.blue, lineWidth: 2)
                    )
                    
                    if switchesSelected {
                        HStack {
                            Toggle("", isOn: $toggleOn)
                                .toggleStyle(SwitchToggleStyle(tint: .green))
                                .labelsHidden()
                                .padding()

                            Toggle("", isOn: $toggleOn)
                                .toggleStyle(SwitchToggleStyle(tint: .green))
                                .labelsHidden()
                                .padding()
                        }
                    }
                    
                    if !switchesSelected {
                        Button("Do Something") {
                            showPopup = true
                        }
                        .font(.system(size: 20))
                        .padding()
                    }
                    Spacer()
                }
                
                if showPopup {
                    ZStack {
                        Color.gray.opacity(0.6)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(20)
                        ZStack {
                            Color.white.opacity(0.9)
                                .frame(width: 330, height: 190)
                                .cornerRadius(20)
                            VStack {
                                Text("Something was done.")
                                    .font(.system(size: 22))
                                    .bold()
                                    .padding(.top, 20)
                                    .padding(.bottom, 10)
                                
                                Text("Everything's fine. You can breathe easy now and continue.")
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal, 20)
                                Spacer()
                                
                                Button("OK") {
                                    showPopup = false
                                }
                                .font(.system(size: 20))
                                .background(Color.white.opacity(0))
                                .foregroundColor(.blue)
                                .cornerRadius(10)
                                .padding(.bottom, 10)
                                .frame(width: 330, height: 55)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 5)
                                        .stroke(Color.gray, lineWidth: 0.5)
                                )
                            }
                            .frame(maxWidth: 330, maxHeight: 190)
                        }
                    }
                    .edgesIgnoringSafeArea(.all)
                }
            }
        }
}

#Preview {
    ContentView()
}
