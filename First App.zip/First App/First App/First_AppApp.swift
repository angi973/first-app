//
//  First_AppApp.swift
//  First App
//
//  Created by Angi Shi on 2024-09-22.
//

import SwiftUI

@main
struct First_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
