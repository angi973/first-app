//
//  First_AppTests.swift
//  First AppTests
//
//  Created by Angi Shi on 2024-09-22.
//

import Testing
@testable import First_App

struct First_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
